--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5
-- Dumped by pg_dump version 15.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE deneme;
--
-- Name: deneme; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE deneme WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Turkish_T�rkiye.1254';


ALTER DATABASE deneme OWNER TO postgres;

\connect deneme

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: rozetler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rozetler (
    "Id" integer NOT NULL,
    "KullaniciId" integer,
    "RozetIsmi" character varying(30) NOT NULL,
    "RozetSinifi" character varying(30),
    "VerilmeSayisi" integer,
    "VerilmeTarihi" date
);


ALTER TABLE public.rozetler OWNER TO postgres;

--
-- Name: altinrozet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.altinrozet (
    "RozetId" integer NOT NULL,
    "AltinRozetGereksinim" character varying(255)
)
INHERITS (public.rozetler);


ALTER TABLE public.altinrozet OWNER TO postgres;

--
-- Name: asagioy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.asagioy (
    "OyTipiId" integer NOT NULL,
    "ItibarEksi" integer
);


ALTER TABLE public.asagioy OWNER TO postgres;

--
-- Name: bronzrozet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bronzrozet (
    "RozetId" integer NOT NULL,
    "BronzRozetGereksinim" character varying(255)
)
INHERITS (public.rozetler);


ALTER TABLE public.bronzrozet OWNER TO postgres;

--
-- Name: kullanicilar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kullanicilar (
    "Id" integer NOT NULL,
    "KullaniciIsim" character varying(30) NOT NULL,
    "KullaniciOlmaTarihi" date DEFAULT '2023-12-08'::date,
    "KullaniciSiteBaglantisi" character varying(50),
    "KullaniciProfilResmiBaglantisi" character varying(50),
    "SonGorulme" date DEFAULT '2023-12-08'::date,
    "ProfilGoruntulenmesi" integer,
    "HakkindaGovdesi" character varying(255),
    "Yas" integer,
    "ItibarSayisi" integer,
    "ZiyaretEdilmeSayisi" integer,
    "SoruSayisi" integer
);


ALTER TABLE public.kullanicilar OWNER TO postgres;

--
-- Name: editor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.editor (
    "KullaniciId" integer NOT NULL,
    "DuzenlenmisSorular" character varying(500),
    "DuzenlenmisYanitlar" character varying(500),
    "DuzenlenmisEtiketler" character varying(100)
)
INHERITS (public.kullanicilar);


ALTER TABLE public.editor OWNER TO postgres;

--
-- Name: etiketler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etiketler (
    "Id" integer,
    "EtiketIsmi" character varying(50),
    "EtiketSinifi" character varying(50),
    "EtiketSayisi" integer,
    "EtiketBilgisi" character varying(255)
);


ALTER TABLE public.etiketler OWNER TO postgres;

--
-- Name: gumusrozet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gumusrozet (
    "RozetId" integer NOT NULL,
    "GumusRozetGereksinim" character varying(255)
)
INHERITS (public.rozetler);


ALTER TABLE public.gumusrozet OWNER TO postgres;

--
-- Name: oylar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oylar (
    "Id" integer NOT NULL,
    "SoruId" integer,
    "KullaniciId" integer,
    "OylanmaZamani" date
);


ALTER TABLE public.oylar OWNER TO postgres;

--
-- Name: oytipi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oytipi (
    "Id" integer NOT NULL,
    "OyId" integer,
    "OyIsmi" character varying(15)
);


ALTER TABLE public.oytipi OWNER TO postgres;

--
-- Name: soruetiketleri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.soruetiketleri (
    "SoruId" integer,
    "EtiketId" integer
);


ALTER TABLE public.soruetiketleri OWNER TO postgres;

--
-- Name: sorular; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sorular (
    "Id" integer NOT NULL,
    "EtiketId" integer,
    "SoruSahibiId" integer,
    "SoruBasligi" character varying(100),
    "SoruGovdesi" character varying(500),
    "YorumSayisi" integer,
    "GoruntulenmeSayisi" integer,
    "OylanmaSayisi" integer,
    "FiltreId" integer,
    "SonAktiflikTarihi" date,
    "SonDuzenlenmeTarihi" date,
    "FavoriSayisi" integer,
    "OlusturmaTarihi" date
);


ALTER TABLE public.sorular OWNER TO postgres;

--
-- Name: yanitlar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yanitlar (
    "Id" integer NOT NULL,
    "OyId" integer,
    "SoruId" integer,
    "KullaniciId" integer,
    "YanitGovdesi" character varying(500),
    "YanitlanmaZamani" date
);


ALTER TABLE public.yanitlar OWNER TO postgres;

--
-- Name: yonetici; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yonetici (
    "KullaniciId" integer NOT NULL,
    "TumSistemYetkisi" boolean
)
INHERITS (public.kullanicilar);


ALTER TABLE public.yonetici OWNER TO postgres;

--
-- Name: yukarioy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yukarioy (
    "OyTipiId" integer NOT NULL,
    "ItibarArti" integer
);


ALTER TABLE public.yukarioy OWNER TO postgres;

--
-- Name: editor KullaniciOlmaTarihi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor ALTER COLUMN "KullaniciOlmaTarihi" SET DEFAULT '2023-12-08'::date;


--
-- Name: editor SonGorulme; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor ALTER COLUMN "SonGorulme" SET DEFAULT '2023-12-08'::date;


--
-- Name: yonetici KullaniciOlmaTarihi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yonetici ALTER COLUMN "KullaniciOlmaTarihi" SET DEFAULT '2023-12-08'::date;


--
-- Name: yonetici SonGorulme; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yonetici ALTER COLUMN "SonGorulme" SET DEFAULT '2023-12-08'::date;


--
-- Data for Name: altinrozet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.altinrozet ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi", "RozetId", "AltinRozetGereksinim") FROM stdin;
\.
COPY public.altinrozet ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi", "RozetId", "AltinRozetGereksinim") FROM '$$PATH$$/3425.dat';

--
-- Data for Name: asagioy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.asagioy ("OyTipiId", "ItibarEksi") FROM stdin;
\.
COPY public.asagioy ("OyTipiId", "ItibarEksi") FROM '$$PATH$$/3426.dat';

--
-- Data for Name: bronzrozet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bronzrozet ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi", "RozetId", "BronzRozetGereksinim") FROM stdin;
\.
COPY public.bronzrozet ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi", "RozetId", "BronzRozetGereksinim") FROM '$$PATH$$/3427.dat';

--
-- Data for Name: editor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.editor ("Id", "KullaniciIsim", "KullaniciOlmaTarihi", "KullaniciSiteBaglantisi", "KullaniciProfilResmiBaglantisi", "SonGorulme", "ProfilGoruntulenmesi", "HakkindaGovdesi", "Yas", "ItibarSayisi", "ZiyaretEdilmeSayisi", "SoruSayisi", "KullaniciId", "DuzenlenmisSorular", "DuzenlenmisYanitlar", "DuzenlenmisEtiketler") FROM stdin;
\.
COPY public.editor ("Id", "KullaniciIsim", "KullaniciOlmaTarihi", "KullaniciSiteBaglantisi", "KullaniciProfilResmiBaglantisi", "SonGorulme", "ProfilGoruntulenmesi", "HakkindaGovdesi", "Yas", "ItibarSayisi", "ZiyaretEdilmeSayisi", "SoruSayisi", "KullaniciId", "DuzenlenmisSorular", "DuzenlenmisYanitlar", "DuzenlenmisEtiketler") FROM '$$PATH$$/3429.dat';

--
-- Data for Name: etiketler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.etiketler ("Id", "EtiketIsmi", "EtiketSinifi", "EtiketSayisi", "EtiketBilgisi") FROM stdin;
\.
COPY public.etiketler ("Id", "EtiketIsmi", "EtiketSinifi", "EtiketSayisi", "EtiketBilgisi") FROM '$$PATH$$/3430.dat';

--
-- Data for Name: gumusrozet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gumusrozet ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi", "RozetId", "GumusRozetGereksinim") FROM stdin;
\.
COPY public.gumusrozet ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi", "RozetId", "GumusRozetGereksinim") FROM '$$PATH$$/3431.dat';

--
-- Data for Name: kullanicilar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kullanicilar ("Id", "KullaniciIsim", "KullaniciOlmaTarihi", "KullaniciSiteBaglantisi", "KullaniciProfilResmiBaglantisi", "SonGorulme", "ProfilGoruntulenmesi", "HakkindaGovdesi", "Yas", "ItibarSayisi", "ZiyaretEdilmeSayisi", "SoruSayisi") FROM stdin;
\.
COPY public.kullanicilar ("Id", "KullaniciIsim", "KullaniciOlmaTarihi", "KullaniciSiteBaglantisi", "KullaniciProfilResmiBaglantisi", "SonGorulme", "ProfilGoruntulenmesi", "HakkindaGovdesi", "Yas", "ItibarSayisi", "ZiyaretEdilmeSayisi", "SoruSayisi") FROM '$$PATH$$/3428.dat';

--
-- Data for Name: oylar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oylar ("Id", "SoruId", "KullaniciId", "OylanmaZamani") FROM stdin;
\.
COPY public.oylar ("Id", "SoruId", "KullaniciId", "OylanmaZamani") FROM '$$PATH$$/3432.dat';

--
-- Data for Name: oytipi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oytipi ("Id", "OyId", "OyIsmi") FROM stdin;
\.
COPY public.oytipi ("Id", "OyId", "OyIsmi") FROM '$$PATH$$/3433.dat';

--
-- Data for Name: rozetler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rozetler ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi") FROM stdin;
\.
COPY public.rozetler ("Id", "KullaniciId", "RozetIsmi", "RozetSinifi", "VerilmeSayisi", "VerilmeTarihi") FROM '$$PATH$$/3424.dat';

--
-- Data for Name: soruetiketleri; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.soruetiketleri ("SoruId", "EtiketId") FROM stdin;
\.
COPY public.soruetiketleri ("SoruId", "EtiketId") FROM '$$PATH$$/3434.dat';

--
-- Data for Name: sorular; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sorular ("Id", "EtiketId", "SoruSahibiId", "SoruBasligi", "SoruGovdesi", "YorumSayisi", "GoruntulenmeSayisi", "OylanmaSayisi", "FiltreId", "SonAktiflikTarihi", "SonDuzenlenmeTarihi", "FavoriSayisi", "OlusturmaTarihi") FROM stdin;
\.
COPY public.sorular ("Id", "EtiketId", "SoruSahibiId", "SoruBasligi", "SoruGovdesi", "YorumSayisi", "GoruntulenmeSayisi", "OylanmaSayisi", "FiltreId", "SonAktiflikTarihi", "SonDuzenlenmeTarihi", "FavoriSayisi", "OlusturmaTarihi") FROM '$$PATH$$/3435.dat';

--
-- Data for Name: yanitlar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yanitlar ("Id", "OyId", "SoruId", "KullaniciId", "YanitGovdesi", "YanitlanmaZamani") FROM stdin;
\.
COPY public.yanitlar ("Id", "OyId", "SoruId", "KullaniciId", "YanitGovdesi", "YanitlanmaZamani") FROM '$$PATH$$/3436.dat';

--
-- Data for Name: yonetici; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yonetici ("Id", "KullaniciIsim", "KullaniciOlmaTarihi", "KullaniciSiteBaglantisi", "KullaniciProfilResmiBaglantisi", "SonGorulme", "ProfilGoruntulenmesi", "HakkindaGovdesi", "Yas", "ItibarSayisi", "ZiyaretEdilmeSayisi", "SoruSayisi", "KullaniciId", "TumSistemYetkisi") FROM stdin;
\.
COPY public.yonetici ("Id", "KullaniciIsim", "KullaniciOlmaTarihi", "KullaniciSiteBaglantisi", "KullaniciProfilResmiBaglantisi", "SonGorulme", "ProfilGoruntulenmesi", "HakkindaGovdesi", "Yas", "ItibarSayisi", "ZiyaretEdilmeSayisi", "SoruSayisi", "KullaniciId", "TumSistemYetkisi") FROM '$$PATH$$/3437.dat';

--
-- Data for Name: yukarioy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yukarioy ("OyTipiId", "ItibarArti") FROM stdin;
\.
COPY public.yukarioy ("OyTipiId", "ItibarArti") FROM '$$PATH$$/3438.dat';

--
-- Name: altinrozet AltinRozetPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.altinrozet
    ADD CONSTRAINT "AltinRozetPK" PRIMARY KEY ("RozetId");


--
-- Name: asagioy AsagiOyPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asagioy
    ADD CONSTRAINT "AsagiOyPK" PRIMARY KEY ("OyTipiId");


--
-- Name: bronzrozet BronzRozetPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bronzrozet
    ADD CONSTRAINT "BronzRozetPK" PRIMARY KEY ("RozetId");


--
-- Name: editor EditorPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT "EditorPK" PRIMARY KEY ("KullaniciId");


--
-- Name: etiketler Etiketler_Id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etiketler
    ADD CONSTRAINT "Etiketler_Id_key" UNIQUE ("Id");


--
-- Name: gumusrozet GumusRozetPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gumusrozet
    ADD CONSTRAINT "GumusRozetPK" PRIMARY KEY ("RozetId");


--
-- Name: kullanicilar KullanicilarPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT "KullanicilarPK" PRIMARY KEY ("Id");


--
-- Name: oytipi OyTipiPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oytipi
    ADD CONSTRAINT "OyTipiPK" PRIMARY KEY ("Id");


--
-- Name: oylar OylarPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oylar
    ADD CONSTRAINT "OylarPK" PRIMARY KEY ("Id");


--
-- Name: rozetler RozetlerPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rozetler
    ADD CONSTRAINT "RozetlerPK" PRIMARY KEY ("Id");


--
-- Name: sorular SorularPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sorular
    ADD CONSTRAINT "SorularPK" PRIMARY KEY ("Id");


--
-- Name: sorular Sorular_OlusturmaTarihi_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sorular
    ADD CONSTRAINT "Sorular_OlusturmaTarihi_key" UNIQUE ("OlusturmaTarihi");


--
-- Name: yanitlar YanitlarPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yanitlar
    ADD CONSTRAINT "YanitlarPK" PRIMARY KEY ("Id");


--
-- Name: yonetici YoneticiPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yonetici
    ADD CONSTRAINT "YoneticiPK" PRIMARY KEY ("KullaniciId");


--
-- Name: yukarioy YukariOyPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yukarioy
    ADD CONSTRAINT "YukariOyPK" PRIMARY KEY ("OyTipiId");


--
-- Name: altinrozet AltinRozetFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.altinrozet
    ADD CONSTRAINT "AltinRozetFK" FOREIGN KEY ("RozetId") REFERENCES public.rozetler("Id");


--
-- Name: asagioy AsagiOyFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asagioy
    ADD CONSTRAINT "AsagiOyFK" FOREIGN KEY ("OyTipiId") REFERENCES public.oytipi("Id");


--
-- Name: bronzrozet BronzRozetFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bronzrozet
    ADD CONSTRAINT "BronzRozetFK" FOREIGN KEY ("RozetId") REFERENCES public.rozetler("Id");


--
-- Name: editor EditorFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editor
    ADD CONSTRAINT "EditorFK" FOREIGN KEY ("KullaniciId") REFERENCES public.kullanicilar("Id");


--
-- Name: gumusrozet GumusRozetFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gumusrozet
    ADD CONSTRAINT "GumusRozetFK" FOREIGN KEY ("RozetId") REFERENCES public.rozetler("Id");


--
-- Name: oytipi OyTipiFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oytipi
    ADD CONSTRAINT "OyTipiFK" FOREIGN KEY ("OyId") REFERENCES public.oylar("Id");


--
-- Name: oylar OylarKullaniciFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oylar
    ADD CONSTRAINT "OylarKullaniciFK" FOREIGN KEY ("KullaniciId") REFERENCES public.kullanicilar("Id");


--
-- Name: oylar OylarSoruFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oylar
    ADD CONSTRAINT "OylarSoruFK" FOREIGN KEY ("SoruId") REFERENCES public.sorular("Id");


--
-- Name: rozetler RozetlerFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rozetler
    ADD CONSTRAINT "RozetlerFK" FOREIGN KEY ("KullaniciId") REFERENCES public.kullanicilar("Id");


--
-- Name: soruetiketleri SoruEtiketleriEtiketFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soruetiketleri
    ADD CONSTRAINT "SoruEtiketleriEtiketFK" FOREIGN KEY ("EtiketId") REFERENCES public.etiketler("Id");


--
-- Name: soruetiketleri SoruEtiketleriSoruFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soruetiketleri
    ADD CONSTRAINT "SoruEtiketleriSoruFK" FOREIGN KEY ("SoruId") REFERENCES public.sorular("Id");


--
-- Name: sorular SorularEtiketFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sorular
    ADD CONSTRAINT "SorularEtiketFK" FOREIGN KEY ("EtiketId") REFERENCES public.etiketler("Id");


--
-- Name: sorular SorularSoruSahibiFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sorular
    ADD CONSTRAINT "SorularSoruSahibiFK" FOREIGN KEY ("SoruSahibiId") REFERENCES public.kullanicilar("Id");


--
-- Name: yanitlar YanitlarKullaniciIdFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yanitlar
    ADD CONSTRAINT "YanitlarKullaniciIdFK" FOREIGN KEY ("KullaniciId") REFERENCES public.kullanicilar("Id");


--
-- Name: yanitlar YanitlarOyIdFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yanitlar
    ADD CONSTRAINT "YanitlarOyIdFK" FOREIGN KEY ("OyId") REFERENCES public.oylar("Id");


--
-- Name: yanitlar YanitlarSoruIdFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yanitlar
    ADD CONSTRAINT "YanitlarSoruIdFK" FOREIGN KEY ("SoruId") REFERENCES public.sorular("Id");


--
-- Name: yonetici YoneticiFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yonetici
    ADD CONSTRAINT "YoneticiFK" FOREIGN KEY ("KullaniciId") REFERENCES public.kullanicilar("Id");


--
-- Name: yukarioy YukariOyFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yukarioy
    ADD CONSTRAINT "YukariOyFK" FOREIGN KEY ("OyTipiId") REFERENCES public.oytipi("Id");


--
-- PostgreSQL database dump complete
--

